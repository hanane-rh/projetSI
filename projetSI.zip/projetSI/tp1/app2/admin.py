from django.contrib import admin
from.models import product,Ingredient,category
# Register your models here.
from .models import product,Ingredient,category

admin.site.register(product)
admin.site.register(Ingredient)
admin.site.register(category)
