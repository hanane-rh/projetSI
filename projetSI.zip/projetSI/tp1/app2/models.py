from django.db import models
from django.utils import  timezone 

 
class category(models.Model):
    ID_cat=models.AutoField(primary_key=True)
    CAT_NAME=models.CharField(max_length=50)

class Ingredient(models.Model):
    ID_ing=models.AutoField(primary_key=True)
    ing_Name=models.CharField(max_length=30)
   # se-compose=models.ManyToManyField(product, related_name="prds")

# Create your models here.
class product(models.Model):
    id_prd=models.AutoField(primary_key=True)
    prd_name=models.CharField(max_length=50)
    price=models.IntegerField
    created_at=models.DateTimeField(auto_now=True)
    ctgrs = models.ForeignKey(category,on_delete=models.CASCADE)
    ings=models.ManyToManyField("Ingredient",related_name="prods")
    def __str__(self):
         return self.name +"("+str (self.prix)+")"
    
class Commande(models.Model): 
     Description_cmd = models.CharField(max_length=50) 
     Date_cmd = models.DateField(default=timezone.now) #Par défaut, la date actuelle  
     Produit_cmd = models.ForeignKey(product, on_delete=models.CASCADE) 
     
     def __str__(self): 
         return self.Description_cmd 
